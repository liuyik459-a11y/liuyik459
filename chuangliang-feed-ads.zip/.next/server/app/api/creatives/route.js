(()=>{var a={};a.id=736,a.ids=[736],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},3578:(a,b,c)=>{"use strict";c.d(b,{S:()=>u,L:()=>s});var d=c(79868),e=c(73024),f=c.n(e),g=c(76760),h=c.n(g);function i(a,b=0){let c=new Date;return c.setDate(c.getDate()-a),c.setHours(9+b,24,0,0),c.toISOString()}let j=[{id:"acc_1",name:"创量优品旗舰店",baiduUserId:"BD-880120931",industry:"美妆个护",status:"投放中",balance:128650,dailyBudget:5e3,authStatus:"已授权",operator:"运营小张"},{id:"acc_2",name:"简衣家居服饰",baiduUserId:"BD-880120932",industry:"服饰鞋包",status:"投放中",balance:86200,dailyBudget:4e3,authStatus:"已授权",operator:"运营小李"},{id:"acc_3",name:"鲜食优选食品",baiduUserId:"BD-880120933",industry:"食品生鲜",status:"投放中",balance:42300,dailyBudget:3e3,authStatus:"已授权",operator:"运营小张"},{id:"acc_4",name:"智享数码配件",baiduUserId:"BD-880120934",industry:"3C数码",status:"投放中",balance:210800,dailyBudget:8e3,authStatus:"已授权",operator:"运营小王"},{id:"acc_5",name:"轻养健康生活",baiduUserId:"BD-880120935",industry:"保健养生",status:"暂停",balance:15600,dailyBudget:2e3,authStatus:"已授权",operator:"运营小李"},{id:"acc_6",name:"潮流鞋靴集合店",baiduUserId:"BD-880120936",industry:"服饰鞋包",status:"余额不足",balance:1200,dailyBudget:2500,authStatus:"待重新授权",operator:"运营小王"}],k={acc_1:["玻尿酸面膜-拉新-信息流","抗老精华-复购-信息流","彩妆套装-大促-信息流"],acc_2:["秋冬加绒卫衣-拉新-信息流","家居四件套-种草-信息流","基础打底衫-复购-信息流"],acc_3:["坚果零食礼包-拉新-信息流","低脂代餐-兴趣人群-信息流","生鲜水果-大促-信息流"],acc_4:["氮化镓充电器-拉新-信息流","磁吸充电宝-种草-信息流","数据线三件套-复购-信息流"],acc_5:["轻养蛋白粉-兴趣人群-信息流","维生素C泡腾片-拉新-信息流","护肝片-复购-信息流"],acc_6:["老爹鞋-拉新-信息流","马丁靴-大促-信息流","帆布鞋-种草-信息流"]},l=["全国 \xb7 18-35岁 \xb7 移动端 \xb7 全部时段","一二线城市 \xb7 25-40岁 \xb7 iOS优先 \xb7 8:00-24:00","广东/江苏/浙江 \xb7 18-30岁 \xb7 女性 \xb7 全时段","全国 \xb7 20-45岁 \xb7 兴趣人群包 \xb7 9:00-23:00"],m={acc_1:128,acc_2:169,acc_3:69,acc_4:219,acc_5:188,acc_6:199},n=[["mat_1","秋冬加绒卫衣\xb7主图A","图片","1080\xd71080","服饰","#ff9a76","#ff4d4f","可用",.041,36],["mat_2","加绒卫衣\xb7模特上身视频","视频","15s \xb7 720P","服饰","#7c9cff","#3b5bdb","可用",.052,28],["mat_3","玻尿酸补水面膜\xb7产品图","图片","1080\xd71080","美妆","#ffb3c7","#e64980","可用",.038,41],["mat_4","面膜\xb7使用场景视频","视频","20s \xb7 1080P","美妆","#c4a7ff","#7048e8","可用",.061,22],["mat_5","坚果零食大礼包\xb7主图","图片","1080\xd71080","食品","#ffd43b","#f08c00","可用",.045,33],["mat_6","氮化镓充电器\xb7卖点图","图片","1080\xd71080","3C","#8ce99a","#2f9e44","审核中",.033,9],["mat_7","充电器\xb7快充对比视频","视频","18s \xb7 1080P","3C","#66d9e8","#1098ad","可用",.057,17],["mat_8","老爹鞋\xb7街拍图","图片","1080\xd71080","鞋靴","#d0bfff","#6741d9","可用",.036,12],["mat_9","轻养蛋白粉\xb7冲泡视频","视频","12s \xb7 720P","保健","#b2f2bb","#37b24d","已驳回",.028,5],["mat_10","家居四件套\xb7场景图","图片","1080\xd71080","家居","#ffc9c9","#c92a2a","可用",.048,24]],o=["今年秋冬就穿它，加绒加厚不臃肿，现在下单立减50","一件顶三件，洗衣机随便造，通勤约会都好看","皮肤干到起皮？用它敷一次，第二天水润一整天","熬夜脸救星来了，补水锁水，敏感肌也能用","办公室囤货首选，独立包装，好吃不腻还顶饱","用了它才知道，原来充电可以这么快","百搭不挑脚型，走一天都不累，尺码齐全","换上这套四件套，卧室质感直接翻倍"],p=[["rule_1","高消耗低转化止损","消耗",">",800,"暂停计划","全部账户","启用",12,1],["rule_2","转化成本超阈值降价","转化成本",">",80,"出价下调 10%","服饰鞋包账户","启用",6,2],["rule_3","优秀 ROI 自动加预算","ROI",">",2.6,"日预算上调 20%","全部账户","启用",3,3],["rule_4","账户余额不足预警","账户余额","<",3e3,"发送飞书通知","全部账户","启用",2,0],["rule_5","夜间低效时段止损","时段消耗",">",200,"暂停 00:00-07:00","全部账户","停用",0,null]],q=[["批量创建","投放任务「秋冬卫衣批量拉新」","覆盖 3 个账户，创建 9 条计划、9 条创意","运营小张",0,10],["规则触发","规则「高消耗低转化止损」","计划「生鲜水果-大促-信息流」消耗 862 元、转化 1 个，已自动暂停","系统",1,14],["数据同步","账户「智享数码配件」","同步最近 7 天投放数据成功，消耗 41,268 元","系统",1,9],["素材上传","素材「充电器\xb7快充对比视频」","上传视频素材，时长 18s，分辨率 1080P","运营小王",2,16],["计划调整","计划「抗老精华-复购-信息流」","日预算由 1,200 元调整为 1,500 元","运营小张",2,11],["账户授权","账户「潮流鞋靴集合店」","授权状态变为待重新授权，请及时处理","系统",3,15],["规则触发","规则「转化成本超阈值降价」","计划「马丁靴-大促-信息流」转化成本 96.4 元，出价已下调 10%","系统",3,9],["素材上传","素材「玻尿酸补水面膜\xb7产品图」","上传图片素材，尺寸 1080\xd71080","运营小李",4,13],["批量创建","投放任务「3C 数码配件批量测试」","覆盖 2 个账户，创建 6 条计划、12 条创意","运营小王",5,10],["计划调整","计划「坚果零食礼包-拉新-信息流」","暂停投放：库存不足","运营小张",6,17]],r=`
CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  baidu_user_id TEXT NOT NULL,
  industry TEXT NOT NULL,
  status TEXT NOT NULL,
  balance REAL NOT NULL,
  daily_budget REAL NOT NULL,
  auth_status TEXT NOT NULL,
  operator TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS plans (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL,
  budget REAL NOT NULL,
  bid REAL NOT NULL,
  targeting TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stats (
  id TEXT PRIMARY KEY,
  date TEXT NOT NULL,
  account_id TEXT NOT NULL,
  plan_id TEXT NOT NULL,
  impressions INTEGER NOT NULL,
  clicks INTEGER NOT NULL,
  cost REAL NOT NULL,
  conversions INTEGER NOT NULL,
  revenue REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_stats_date ON stats(date);
CREATE INDEX IF NOT EXISTS idx_stats_account ON stats(account_id);

CREATE TABLE IF NOT EXISTS materials (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  type TEXT NOT NULL,
  size TEXT NOT NULL,
  tag TEXT NOT NULL,
  color_a TEXT NOT NULL,
  color_b TEXT NOT NULL,
  status TEXT NOT NULL,
  ctr REAL NOT NULL,
  used_count INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS creatives (
  id TEXT PRIMARY KEY,
  plan_id TEXT NOT NULL,
  material_id TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS batch_tasks (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  account_ids TEXT NOT NULL,
  plan_count INTEGER NOT NULL,
  unit_count INTEGER NOT NULL,
  creative_count INTEGER NOT NULL,
  status TEXT NOT NULL,
  progress INTEGER NOT NULL,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rules (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  metric TEXT NOT NULL,
  operator TEXT NOT NULL,
  threshold REAL NOT NULL,
  action TEXT NOT NULL,
  scope TEXT NOT NULL,
  status TEXT NOT NULL,
  triggered_count INTEGER NOT NULL,
  last_triggered_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS logs (
  id TEXT PRIMARY KEY,
  action TEXT NOT NULL,
  target TEXT NOT NULL,
  detail TEXT NOT NULL,
  operator TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
`;function s(){if(globalThis.__feedAdsDb)return globalThis.__feedAdsDb;let a=h().join(process.cwd(),"data");f().mkdirSync(a,{recursive:!0});let b=new d.DatabaseSync(h().join(a,"app.db"));b.exec("PRAGMA journal_mode = WAL;"),b.exec(r),t(b,"plans","baidu_id","TEXT"),t(b,"plans","baidu_adgroup_id","TEXT");let c=b.prepare("SELECT COUNT(*) AS c FROM accounts").get();return c&&0!==Number(c.c)||function(a){let b=a.prepare(`INSERT INTO accounts (id, name, baidu_user_id, industry, status, balance, daily_budget, auth_status, operator, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`),c=a.prepare(`INSERT INTO plans (id, account_id, name, status, budget, bid, targeting, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`),d=a.prepare(`INSERT INTO stats (id, date, account_id, plan_id, impressions, clicks, cost, conversions, revenue)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);for(let a of j)b.run(a.id,a.name,a.baiduUserId,a.industry,a.status,a.balance,a.dailyBudget,a.authStatus,a.operator,new Date().toISOString());let e=new Date;e.setHours(0,0,0,0);let f=[];j.forEach((a,b)=>{k[a.id].forEach((d,e)=>{let g=`plan_${b+1}_${e+1}`;f.push(g),c.run(g,a.id,d,"暂停"===a.status?"暂停":1===e?"审核中":"投放中",Math.round(a.dailyBudget/3),.6+.15*e,l[(b+e)%l.length],i(20+3*b+e,e))})});for(let a=89;a>=0;a--){let b=new Date(e.getTime()-864e5*a),c=function(a){let b=a.getFullYear(),c=`${a.getMonth()+1}`.padStart(2,"0"),d=`${a.getDate()}`.padStart(2,"0");return`${b}-${c}-${d}`}(b),f=b.getDay(),g=0===f||6===f;j.forEach((b,e)=>{k[b.id].forEach((f,h)=>{let i=`plan_${e+1}_${h+1}`,j=function(a){return function(){a|=0;let b=Math.imul((a=a+0x6d2b79f5|0)^a>>>15,1|a);return(((b=b+Math.imul(b^b>>>7,61|b)^b)^b>>>14)>>>0)/0x100000000}}(function(a){let b=0x811c9dc5;for(let c=0;c<a.length;c++)b^=a.charCodeAt(c),b=Math.imul(b,0x1000193);return b>>>0}(i+c)),k=.62+.38*j();g&&["acc_1","acc_2","acc_3","acc_6"].includes(b.id)&&(k*=1.18),"acc_5"===b.id&&a<30&&(k=0),"acc_6"===b.id&&a<4&&(k=0),"暂停"===b.status&&a<21&&(k=0);let l=b.dailyBudget/3*k;if(l<=0)return void d.run(`stat_${i}_${c}`,c,b.id,i,0,0,0,0,0);let n=.5+.85*j(),o=.014+.026*j(),p=.007+.013*j(),q=m[b.id]*(.9+.25*j()),r=Math.max(1,Math.round(l/n)),s=Math.max(r,Math.round(r/o)),t=Math.max(0,Math.round(r*p)),u=Math.round(t*q);d.run(`stat_${i}_${c}`,c,b.id,i,s,r,Number(l.toFixed(2)),t,u)})})}let g=a.prepare(`INSERT INTO materials (id, title, type, size, tag, color_a, color_b, status, ctr, used_count, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);for(let a of n)g.run(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],i(6,3));let h=a.prepare(`INSERT INTO creatives (id, plan_id, material_id, title, description, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`);o.forEach((a,b)=>{let c=f[b%f.length],d=n[b%n.length][0];h.run(`creative_${b+1}`,c,d,a,"点击查看详情，限时优惠进行中",b%5==4?"审核中":"可用",i(3+b%5,b%8))});let r=a.prepare(`INSERT INTO batch_tasks (id, name, account_ids, plan_count, unit_count, creative_count, status, progress, created_by, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);r.run("task_seed_1","秋冬卫衣批量拉新",JSON.stringify(["acc_2","acc_6"]),9,9,9,"已完成",100,"运营小张",i(3,2)),r.run("task_seed_2","3C 数码配件批量测试",JSON.stringify(["acc_4"]),6,6,12,"已完成",100,"运营小王",i(5,4));let s=a.prepare(`INSERT INTO rules (id, name, metric, operator, threshold, action, scope, status, triggered_count, last_triggered_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);for(let a of p)s.run(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],null===a[9]?null:i(a[9],4),i(15,1));let t=a.prepare("INSERT INTO logs (id, action, target, detail, operator, created_at) VALUES (?, ?, ?, ?, ?, ?)");q.forEach((a,b)=>{t.run(`log_seed_${b+1}`,a[0],a[1],a[2],a[3],i(a[4],a[5]))})}(b),globalThis.__feedAdsDb=b,b}function t(a,b,c,d){a.prepare(`PRAGMA table_info(${b})`).all().some(a=>a.name===c)||a.exec(`ALTER TABLE ${b} ADD COLUMN ${c} ${d}`)}function u(a,b,c,d,e="运营小张"){a.prepare("INSERT INTO logs (id, action, target, detail, operator, created_at) VALUES (?, ?, ?, ?, ?, ?)").run(`log_${Date.now().toString(36)}${Math.random().toString(36).slice(2,6)}`,b,c,d,e,new Date().toISOString())}},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},26198:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>F,patchFetch:()=>E,routeModule:()=>A,serverHooks:()=>D,workAsyncStorage:()=>B,workUnitAsyncStorage:()=>C});var d={};c.r(d),c.d(d,{GET:()=>z,dynamic:()=>y,runtime:()=>x});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(34679),u=c(51356),v=c(10641),w=c(3578);let x="nodejs",y="force-dynamic";async function z(){let a=(0,w.L)().prepare(`SELECT c.id, c.title, c.description, c.status, c.created_at,
              m.title AS material_title, m.type AS material_type, m.color_a, m.color_b,
              p.name AS plan_name, a.name AS account_name
       FROM creatives c
       LEFT JOIN materials m ON m.id = c.material_id
       LEFT JOIN plans p ON p.id = c.plan_id
       LEFT JOIN accounts a ON a.id = p.account_id
       ORDER BY c.created_at DESC LIMIT 30`).all();return v.NextResponse.json({data:a.map(a=>({id:a.id,title:a.title,description:a.description,status:a.status,createdAt:a.created_at,materialTitle:a.material_title,materialType:a.material_type,colorA:a.color_a,colorB:a.color_b,planName:a.plan_name,accountName:a.account_name}))})}let A=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/creatives/route",pathname:"/api/creatives",filename:"route",bundlePath:"app/api/creatives/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/workspace/app/api/creatives/route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:B,workUnitAsyncStorage:C,serverHooks:D}=A;function E(){return(0,g.patchFetch)({workAsyncStorage:B,workUnitAsyncStorage:C})}async function F(a,b,c){var d;let e="/api/creatives/route";"/index"===e&&(e="/");let g=await A.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:v,params:w,nextConfig:x,isDraftMode:y,prerenderManifest:z,routerServerContext:B,isOnDemandRevalidate:C,revalidateOnlyGenerated:D,resolvedPathname:E}=g,F=(0,j.normalizeAppPath)(e),G=!!z.routes[E]&&(A.isDev||(0,t.isRouteCacheOwner)(E,A.cacheOwner,z.routes[E])),H=!!(z.dynamicRoutes[F]||G);if(H&&!y){let a=z.dynamicRoutes[F];if(a&&!1===a.fallback&&!G)throw new s.NoFallbackError}let I=null;!H||A.isDev||y||(I="/index"===(I=E)?"/":I);let J=!0===A.isDev||!H,K=H&&!J,L=a.method||"GET",M=(0,i.getTracer)(),N=M.getActiveScopeSpan(),O={params:w,prerenderManifest:z,renderOpts:{experimental:{cacheComponents:!!x.experimental.cacheComponents,authInterrupts:!!x.experimental.authInterrupts},supportsDynamicResponse:J,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=x.experimental)?void 0:d.cacheLife,isRevalidate:K,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>A.onRequestError(a,b,d,B)},sharedContext:{buildId:v}},P=new k.NodeNextRequest(a),Q=new k.NodeNextResponse(b),R=l.NextRequestAdapter.fromNodeNextRequest(P,(0,l.signalFromNodeResponse)(b));try{let d=async c=>A.handle(R,O).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=M.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${L} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${L} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&C&&D&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=O.renderOpts.fetchMetrics;let i=O.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=O.renderOpts.collectedTags;if(!H)return await (0,o.I)(P,Q,e,O.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==O.renderOpts.collectedRevalidate&&!(O.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&O.renderOpts.collectedRevalidate,d=void 0===O.renderOpts.collectedExpire||O.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:O.renderOpts.collectedExpire;return{value:{kind:u.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await A.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:K,isOnDemandRevalidate:C})},B),b}},l=await A.handleResponse({req:a,nextConfig:x,cacheKey:I,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:C,revalidateOnlyGenerated:D,responseGenerator:k,waitUntil:c.waitUntil});if(!H)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==u.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",C?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),y&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&H||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(P,Q,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};N?await g(N):await M.withPropagatedContext(a.headers,()=>M.trace(m.BaseServerSpan.handleRequest,{spanName:`${L} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":L,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await A.onRequestError(a,b,{routerKind:"App Router",routePath:F,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:K,isOnDemandRevalidate:C})}),H)throw b;return await (0,o.I)(P,Q,new Response(null,{status:500})),null}}},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{"use strict";a.exports=require("path")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:a=>{"use strict";a.exports=require("crypto")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},73024:a=>{"use strict";a.exports=require("node:fs")},76760:a=>{"use strict";a.exports=require("node:path")},78335:()=>{},79868:a=>{"use strict";a.exports=require("node:sqlite")},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[897,692],()=>b(b.s=26198));module.exports=c})();